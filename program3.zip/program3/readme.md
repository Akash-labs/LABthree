Steps to run the project.

1. Open the project's folder in visual studio code
2. Open the server.js file
3. Add the mondodb atlas url in the "MongoDBUrl" variable (i.e. Line number 12 in the file)
4. Open Terminal and go to the project's folder
5. Run "npm install" command in the terminal
6. To start the server run "npm start" command in the terminal

You need to test the API's using Postman software
